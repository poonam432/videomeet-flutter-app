import 'package:flutter_test/flutter_test.dart';
import 'package:hipster_inc_assignment/features/user_list/data/datasources/user_list_remote_datasource.dart';
import 'package:dio/dio.dart';

void main() {
  group('User List Tests', () {
    late UserListRemoteDataSourceImpl userListRemoteDataSource;

    setUp(() {
      userListRemoteDataSource = UserListRemoteDataSourceImpl(dio: Dio());
    });

    test('should return users successfully (API or fallback)', () async {
      // Act
      final result = await userListRemoteDataSource.getUsers();

      // Assert
      expect(result, isNotEmpty);
      expect(result.length, greaterThan(5)); // Should have at least 6 users
      expect(result.first.firstName, isNotEmpty);
      expect(result.first.lastName, isNotEmpty);
      expect(result.first.email, isNotEmpty);
    });

    test('should return users with valid data', () async {
      // Act
      final result = await userListRemoteDataSource.getUsers();

      // Assert
      for (final user in result) {
        expect(user.id, isNotEmpty);
        expect(user.email, isNotEmpty);
        expect(user.firstName, isNotEmpty);
        expect(user.lastName, isNotEmpty);
        expect(user.avatar, isNotEmpty);
      }
    });

    test('should return users with valid IDs', () async {
      // Act
      final result = await userListRemoteDataSource.getUsers();

      // Assert
      for (int i = 0; i < result.length; i++) {
        expect(result[i].id, equals((i + 1).toString()));
      }
    });
  });
}
