import 'package:flutter_test/flutter_test.dart';
import 'package:hipster_inc_assignment/features/auth/data/datasources/auth_remote_datasource.dart';
import 'package:hipster_inc_assignment/features/auth/data/models/auth_request_model.dart';
import 'package:dio/dio.dart';

void main() {
  group('Auth Tests', () {
    late AuthRemoteDataSourceImpl authRemoteDataSource;

    setUp(() {
      authRemoteDataSource = AuthRemoteDataSourceImpl(dio: Dio());
    });

    test('should login successfully with valid credentials', () async {
      // Arrange
      final request = AuthRequestModel(
        email: 'john.doe@example.com',
        password: 'password123',
      );

      // Act
      final result = await authRemoteDataSource.login(request);

      // Assert
      expect(result.token, isNotEmpty);
      expect(result.user.email, equals('john.doe@example.com'));
      expect(result.user.firstName, equals('John Doe'));
    });

    test('should fail with invalid credentials', () async {
      // Arrange
      final request = AuthRequestModel(
        email: 'test@example.com',
        password: '123', // Too short
      );

      // Act & Assert
      expect(
        () => authRemoteDataSource.login(request),
        throwsA(isA<Exception>()),
      );
    });

    test('should fail with empty email', () async {
      // Arrange
      final request = AuthRequestModel(
        email: '',
        password: 'password123',
      );

      // Act & Assert
      expect(
        () => authRemoteDataSource.login(request),
        throwsA(isA<Exception>()),
      );
    });
  });
}



