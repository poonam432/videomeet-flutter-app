#import <FlutterMacOS/FlutterMacOS.h>

@interface AgoraRtcNgPlugin : NSObject<FlutterPlugin>
@end
