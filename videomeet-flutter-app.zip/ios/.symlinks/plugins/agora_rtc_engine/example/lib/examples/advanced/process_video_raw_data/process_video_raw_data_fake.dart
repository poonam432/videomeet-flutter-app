import 'package:flutter/material.dart';

class ProcessVideoRawData extends StatefulWidget {
  const ProcessVideoRawData({Key? key}) : super(key: key);

  @override
  State<ProcessVideoRawData> createState() => _ProcessVideoRawDataState();
}

class _ProcessVideoRawDataState extends State<ProcessVideoRawData> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
