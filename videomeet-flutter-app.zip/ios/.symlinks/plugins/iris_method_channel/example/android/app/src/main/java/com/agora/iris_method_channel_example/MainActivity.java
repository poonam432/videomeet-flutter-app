package com.agora.iris_method_channel_example;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
