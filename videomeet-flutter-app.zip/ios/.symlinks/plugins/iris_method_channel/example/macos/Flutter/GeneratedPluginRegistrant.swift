//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import iris_method_channel

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  IrisMethodChannelPlugin.register(with: registry.registrar(forPlugin: "IrisMethodChannelPlugin"))
}
