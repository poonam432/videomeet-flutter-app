#!/bin/bash

cd example
flutter packags get
flutter test integration_test