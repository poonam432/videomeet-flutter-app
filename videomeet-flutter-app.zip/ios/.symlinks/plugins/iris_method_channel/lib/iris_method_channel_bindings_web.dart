// Export the common bindings of iris of web
export 'src/platform/web/bindings/iris_api_common_bindings_js.dart';
