export 'iris_method_channel_internal_expect.dart'
    if (dart.library.io) 'iris_method_channel_internal_actual_io.dart'
    if (dart.library.js) 'iris_method_channel_internal_actual_web.dart';
