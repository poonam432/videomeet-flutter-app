import 'dart:typed_data';

// ignore_for_file: public_member_api_docs

/// Empty implementation on web
Uint8List uint8ListFromPtr(int intPtr, int length) {
  return Uint8List(0);
}
