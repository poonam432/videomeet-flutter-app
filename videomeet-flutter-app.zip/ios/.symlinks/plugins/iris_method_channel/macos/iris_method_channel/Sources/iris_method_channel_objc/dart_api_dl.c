// Ignore warning of [-Wdocumentation/-Wstrict-prototypes] of dart_api_dl.c
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdocumentation"
#pragma clang diagnostic ignored "-Wstrict-prototypes"
#include "../../../../src/dart-sdk/include/dart_api_dl.c"
#pragma clang diagnostic pop
