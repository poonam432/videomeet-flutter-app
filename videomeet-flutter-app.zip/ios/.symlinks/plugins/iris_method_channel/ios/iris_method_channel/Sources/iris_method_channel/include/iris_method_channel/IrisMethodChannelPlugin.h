#import <Flutter/Flutter.h>

@interface IrisMethodChannelPlugin : NSObject<FlutterPlugin>
@end
