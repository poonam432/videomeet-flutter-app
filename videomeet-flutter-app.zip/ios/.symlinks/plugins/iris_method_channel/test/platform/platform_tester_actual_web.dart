import 'fake/fake_platform_binding_delegate_web.dart';
import 'fake/platform_tester_interface.dart';

/// Implementation of create the [PlatformTesterInterface] on web
PlatformTesterInterface getPlatformTester() => PlatformTesterInterfaceWeb();
