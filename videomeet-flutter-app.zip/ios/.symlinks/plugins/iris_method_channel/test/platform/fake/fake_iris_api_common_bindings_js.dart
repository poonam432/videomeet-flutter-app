// The Dart class must have `@JSExport` on it or one of its instance members.
import 'package:js/js.dart';

@JSExport()
class FakeIrisApiEngineJS {
  FakeIrisApiEngineJS();
}
