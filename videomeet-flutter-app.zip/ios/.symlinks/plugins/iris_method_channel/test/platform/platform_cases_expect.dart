/// Stub function for platform specific test cases.
/// See implemetation:
/// io: `platform_cases_actual_io.dart`
/// web: `platform_cases_actual_web.dart`
void platformCases() => throw UnimplementedError('Unimplemented');
